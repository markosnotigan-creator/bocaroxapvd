
import { Product, Customer, Seller, Table, DeliveryOrder, Sale, CashRegister } from '../types';

export enum DBSource {
  LOCAL = 'local',
  CLOUD = 'cloud'
}

interface DBConfig {
  source: DBSource;
  apiUrl?: string;
  apiKey?: string;
}

class DBService {
  private config: DBConfig = {
    source: (localStorage.getItem('br_db_source') as DBSource) || DBSource.LOCAL,
    apiUrl: localStorage.getItem('br_db_api_url') || '',
  };

  getConfig() {
    return this.config;
  }

  updateConfig(newConfig: Partial<DBConfig>) {
    this.config = { ...this.config, ...newConfig };
    localStorage.setItem('br_db_source', this.config.source);
    if (this.config.apiUrl) localStorage.setItem('br_db_api_url', this.config.apiUrl);
  }

  private async request(endpoint: string, method: string = 'GET', data?: any) {
    if (this.config.source === DBSource.LOCAL) {
      const key = `br_${endpoint}`;
      if (method === 'GET') {
        return JSON.parse(localStorage.getItem(key) || '[]');
      } else {
        localStorage.setItem(key, JSON.stringify(data));
        return data;
      }
    }

    // Lógica para Nuvem (API Externa)
    try {
      const response = await fetch(`${this.config.apiUrl}/${endpoint}`, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`
        },
        body: data ? JSON.stringify(data) : undefined
      });
      return await response.json();
    } catch (error) {
      console.error('Erro na conexão com a nuvem:', error);
      // Fallback para local se a nuvem falhar (opcional)
      return JSON.parse(localStorage.getItem(`br_${endpoint}`) || '[]');
    }
  }

  // Métodos Genéricos de Persistência
  async saveAll(collection: string, data: any[]) {
    return this.request(collection, 'POST', data);
  }

  async getAll(collection: string) {
    return this.request(collection, 'GET');
  }
}

export const dbService = new DBService();
